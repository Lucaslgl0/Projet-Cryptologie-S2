import time
import random
import matplotlib.pyplot as plt
import numpy as np
from operations_liste import *
from scipy.ndimage.filters import gaussian_filter1d


plt.style.use("seaborn")
res = 1
x = []
y = []
for i in range(1, 20):
    res = i

    taille = res
    liste3 = [random.randint(0, 9) for i in range(res)]
    liste1 = [random.randint(0, 9) for i in range(100)]
    liste2 = [random.randint(0, 9) for i in range(100)]

    t1 = time.time()
    expo_modulaire(liste1, liste3, liste2)
    t2 = time.time()
    y.append(t2 - t1)
    x.append(res)
    print(
        "L'addition de deux liste de ",
        taille,
        "éléments prend",
        t2 - t1,
        "secondes.",
    )

fig, ax = plt.subplots(figsize=(20, 5))

ax.set_title("temps de multiplication en fonction des tailles des listes", fontsize=30)
ax.set_xlabel("tailles des listes", fontsize=20)
ax.set_ylabel("temps en secondes", fontsize=20)

ysmoothed = gaussian_filter1d(y, sigma=5)
plt.plot(x, y, "co", x, ysmoothed, "-k")
plt.show()
