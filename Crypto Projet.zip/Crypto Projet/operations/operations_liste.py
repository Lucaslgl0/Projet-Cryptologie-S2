from copy import *
from math import *
from random import *

############################################################################################################################
# [------------------------------------------] DEBUT DE NOS FONCTIONS OUTILS [---------------------------------------------]#
############################################################################################################################


def supprime_zéros(liste):
    """Suppression des zéros 'inutiles' à l'avant d'une liste

    Cette fonction modifie la liste en enlevant les zéros inutiles qui se trouvent devant.
    Cette fonction est essentielle pour nous dans certaine fonction qui ne vont pas fonctionner si des zéros se trouve en début de liste.

    Args :
        liste (list) : qui sera notre liste de chiffres à corriger

    Returns :
        None : La fonction ne renvoie rien mais modifie directement la liste.
        (Update) : La fonction renvoie la liste modifiée également (elle continue de modifier la liste initiale car cela prendrait trop de place de faire un deepcopy à chaque fois que l'on appelle cette fonction).
    """
    if liste == []:
        return liste
    while True:
        if liste[0] == 0 and len(liste) != 1:
            del liste[0]
        else:
            t = False
            return liste


def nombre_vers_liste(chiffre):
    """Transformation d'un nombre en une liste

    Dans nos programmes, nous convertissons les nombres en listes car nous nous placerons dans le cas où le langage n'arrive pas à traiter des nombres très grands directement (par exemple le C lorsque le système RSA est sorti).
    Cette fonction nous permet de créer une liste qui représentera un nombre où chaque case de la liste représente un chiffre composant le nombre. Tout notre système va utiliser des listes correspondant à des nombres.
    L'unité sera la dernière case, le chiffre des dizaines sera l'avant-dernière, etc

    Args :
        chiffre (int): sera le nombre en entier qui pourra être, dans notre cas, très grand

    Returns :
        list : Le nombre converti en liste comme décrit plus haut
    """
    new = []
    E = 1
    chiffre = int(chiffre)
    while chiffre % E != chiffre:
        E *= 10
        new = [int((chiffre % E) / (E // 10))] + new
    return new


def change_retenue(L, base=10):
    """Ajout d'une retenue lors d'une opération

    Cette fonction nous permet de supprimer le problème de retenue sur nos opérations.
    Elle sera utilisée lors d'une addition, ajoutera un au nombre en entrée (sous forme d'une liste) et traitera le problème potentiel de la retenue sur chaque élément de la liste.

    Args :
        L (list): notre liste en entrée sur laquelle sera appliquée la retenue
        base (int): Par défaut 10, permet de changer de base si nous le voulons

    Return :
        list : renvoie la liste de départ (+1) mais en ajoutant la retenue si nécéssaire
    """
    if len(L) == 0:
        return [1]

    else:
        if L[-1] != (base - 1):
            L[-1] += 1
            return L
        else:
            L[-1] = 0
        return change_retenue(L[:-1], base) + [L[-1]]


def est_plus_grand(L1, L2):
    """Permet de comparer deux listes

    Cette fonction vérifie, chiffre par chiffre dans la liste, si notre première liste est plus grande que la seconde.
    Cela va nous être utile par la suite lors de différentes opérations.

    Args :
        L1, L2 (list): nos deux listes à comparer

    Return :
        boolean : rend True si L1 est plus grand ou égal à L2 et False sinon
    """
    L1 = supprime_zéros(L1)
    L2 = supprime_zéros(L2)
    if L1 == L2:
        return True
    if len(L1) < len(L2):
        return False
    elif len(L2) < len(L1):
        return True
    for i in range(len(L1)):
        if L1[i] == L2[i]:
            if i == len(L1) - 1:
                return False
            continue
        elif L1[i] < L2[i]:
            return False
        else:
            return True
    return False


def passage_binaire(l1):
    """Convertisseur de la base 10 à la base 2

    Cette fonction convertie la liste correponsant à un nombre en base 10 en une liste correspondant à ce même nombre en base 2.
    Nous utilisons une technique vu au premier semestre avec M. Prcovic en cours d'informatique: nous effectuons une succession de divisions entières par 2 en notant les restes (qui deviendront notre nombre binaire).

    Args :
        l1 (list): la liste (en base 10) à convertir

    Return :
        list : rend la liste convertie en base 2
    """
    L1 = deepcopy(l1)
    res = []
    r = 0
    while L1 != [0] and L1 != [1] and L1 != []:

        l2 = division(L1, [2])
        L1 = l2[0]
        y = l2[1]

        res = y + res

    if L1 == [1]:

        res = [1] + res

    return res


def PGCD(L1, L2):
    """Trouver le PGCD entre 2 listes

    Cette fonction nous permet de trouver le plus grand diviseur commun entre deux listes (correspondant à nos nombres).
    Nous utilisons pour cela l'algorithme d'Euclide. Cette fonction est développée dans notre rapport de projet.

    Args :
        L1, L2 (list): Les deux listes à comparer pour trouver leur PGCD

    Return :
        list : Le PGCD entre les deux listes en entrée
    """
    if est_plus_grand(L2, L1):
        L2, L1 = L1, L2

    while L2 != [0]:
        L1, L2 = L2, division(L1, L2)[1]
    return L1


def liste_vers_nombre(L1):
    """Convertir une liste en un nombre

    Durant tout notre système, nous utilisons des listes à la place de nombres pour comprendre comment les programmeurs faisaient pour développer le système RSA lorsque les langages de programmation ne pouvaient pas traiter de grands nombres.
    Une fois que nous avons effecté tous nos calculs sur des nombres sous la forme de listes, nous pouvons les reconvertir en des nombre (pour que l'affichage soit plus clair) ou bien pour tester nos programmes avec des fonctions natives de Python.
    Cette fonction nous permet cette convertion.

    Args :
        L1 (list): La liste à convertir

    Return :
        int : L'entier correspondant à la liste en entrée
    """
    chiffre = ""
    for element in L1:
        chiffre += str(element)
    chiffre = int(chiffre)
    return chiffre


def trouvepremier(n):
    t = True
    r = False
    while t:
        nombrepremier = []
        for i in range(n - 1):
            nombrepremier += [randint(0, 9)]
        nombrepremier += [randrange(1, 10, 2)]
        b = randint(1, 10 ** (n))
        b = nombre_vers_liste(b)
        if expo_modulaire(b, soustraction(nombrepremier, [1]), nombrepremier) == [1]:

            for i in range(50):
                b = randint(1, 10 ** (n))
                b = nombre_vers_liste(b)
                if expo_modulaire(
                    b, soustraction(nombrepremier, [1]), nombrepremier
                ) == [1]:
                    r = True

                else:
                    r = False
                    break

        if r:
            t = False

    return nombrepremier


############################################################################################################################
# [--------------------------------------------------] FIN DE NOS OUTILS [-------------------------------------------------]#
############################################################################################################################

############################################################################################################################
# [-----------------------------------------] DEBUT DE NOS FONCTIONS OPERATIONS[-------------------------------------------]#
############################################################################################################################


def addition(L1, L2, base=10):
    """Additionne deux listes

    Ceci est notre première opération élémentaire. On souhaite additionner deux listes qui représentent deux nombres.
    On suppose que L1 est plus grand que L2 et si c'est l'inverse, L2 devient L1 et L1 devient L2.
    Nous allons ensuite effectuer l'addition sur chaque élément des deux listes avec les mêmes indices (en partant de la fin) et si notre addition des deux éléments est plus grande que la base nous utilisons la fonction change_retenue; sinon, nous faisons l'addition classique des deux éléments.

    Args :
        L1, L2 (list): Les deux listes à additionner

    Return :
        list : L'addition des deux listes, elle-aussi sous forme de liste
    """
    if len(L1) < len(L2):
        L1, L2 = L2, L1
    taille1 = len(L1)
    taille2 = len(L2)
    new = []
    supplementaire = []
    min_taille = min(taille1, taille2)
    retenue = 0

    for i in range(min_taille):
        if L1[taille1 - 1 - i] + L2[taille2 - 1 - i] + retenue < base:
            new = [L1[taille1 - 1 - i] + L2[taille2 - 1 - i] + retenue] + new
            retenue = 0
        else:
            new = [L1[taille1 - 1 - i] + L2[taille2 - 1 - i] + retenue - base] + new
            retenue = 1
    if taille1 == taille2 and retenue == 1:
        new = [1] + new
        retenue = 0
    if taille1 != taille2:
        if retenue == 1:
            supplementaire = change_retenue(L1[: (taille1 - taille2)])
        else:
            supplementaire = L1[: (taille1 - taille2)]
        new = supplementaire + new
    return new


def soustraction(l1, l2, base=10):
    """
    Soustraction entre deux listes

    Voici notre seconde fonction élémentaire. Effectivement, si nous devons additionner pour chiffrer, il est logique de devoir soustraire pour déchiffrer (faire le chemin inverse).
    Cette fonction rend la valeur absolue de la soustraction de deux listes positives.
    Cette fonction fonctionne de la manière suivante :
    Pour chaque élément de nos listes (en partant de la fin de la liste donc du début du nombre), on soustrait les deux éléments entre eux (l'élément de la première liste moins l'élément de la seconde). Si la soustraction est négative, on enlève 1 à la soustraction au prochain indice et on prend la valeur absolue de la soustraction des deux éléments.
    S'il y a une différence de taille entre la première et la deuxième liste, il nous suffit simplement de rajouter la différence de taille de la première liste au début du résultat.

    Args:
        l1, l2 (list): nos deux listes à soustraire (l'ordre n'importe pas puisque nous rendons la valeur absolue)
        Base (int): par défaut 10, sera la base dans laquelle sera faite l'opération

    Return :
        list: la valeur absolue de la soustraction entre les deux listes en entrée
    """

    L1 = deepcopy(l1)
    L2 = deepcopy(l2)

    if est_plus_grand(L2, L1):
        L1, L2 = L2, L1
    taille1 = len(L1)
    taille2 = len(L2)
    new = []
    compteur = 0
    for i in range(taille2):
        L2[taille2 - 1 - i] += compteur
        if L1[taille1 - 1 - i] - L2[taille2 - 1 - i] < 0:
            compteur = 1
            new = [base + L1[taille1 - 1 - i] - L2[taille2 - 1 - i]] + new
        else:
            new = [L1[taille1 - 1 - i] - L2[taille2 - 1 - i]] + new
            compteur = 0
    if compteur == 1:
        L1[taille1 - taille2 - 1] -= 1
    new = L1[: (taille1 - taille2)] + new
    supprime_zéros(new)
    return new


def multiplication_negative(l1, l2, base=10):
    """
    Multiplication de deux listes qui peuvent être négatives
    La fonction nous permet de traiter le cas de deux listes qui peuvent être négatives mais une fois cette particularité traitée, elle fonctionne comme la fonction multiplication classique.
    Si les deux nombres sont négatifs ou les deux nombres sont positifs alors le résultat sera positif et nous n'avons donc qu'à faire une multiplication classique.
    Si seulement un des deux nombres est négatif alors le résultat sera négatif et nous devrons faire la multiplication classique puis rajouter le terme "négatif" à l'avant de la liste.
    Cette fonction sera utile lorsque nous voudrons faire l'algorithme d'Euclide étendu qui nous demande de traiter des nombres négatifs.
    Le fait d'utiliser la fonction 'supprime_zéros' est essentiel pour l'utilisation de notre fonction en base 2.

    Args:
        l1, l2 (list): seront nos deux listes à multiplier (potentiellement négatives)
        base (int): par défaut 10, sera la base dans laquelle sera faite l'opération

    Return:
        list: une liste représentant le résultat obtenue par la multiplication (qui pourra être négatif, représenté avec une chaine de caractères "négatif" en début de liste)
    """
    L1 = deepcopy(l1)
    L2 = deepcopy(l2)
    negatif = False
    if L1[0] == L2[0] == "negatif":
        L1.remove("negatif")
        L2.remove("negatif")
    elif L1[0] == "negatif":
        negatif = True
        L1.remove("negatif")
    elif L2[0] == "negatif":
        negatif = True
        L2.remove("negatif")

    resultat = [0]
    if len(L1) == len(L2):
        L1 = [0] + L1
    L1, L2 = max(L1, L2, key=len), min(L1, L2, key=len)
    for i in range(len(L2)):
        for j in range(len(L1)):
            resultat = addition(
                resultat,
                (
                    nombre_vers_liste(L1[len(L1) - j - 1] * L2[len(L2) - i - 1])
                    + [0 for i in range(i + j)]
                ),
                base,
            )
    supprime_zéros(resultat)
    if negatif:
        resultat.insert(0, "negatif")
    return resultat


def soustraction_negative(l1, l2, base=10):
    """
    Soustraction de deux listes qui peuvent être négatives
    La fonction nous permet de traiter le cas de deux listes qui peuvent être négatives mais une fois cette particularité traitée, elle fonctionne comme la fonction soustraction classique.
    Si les deux nombres sont négatifs cela revient à faire la soustractions du deuxième par le premier.
    Si la seconde liste est négative, cela revient à faire l'addition des deux listes.
    Si la première liste est négative, cela revient à faire l'addition des deux listes est de rajouter la chaine de caractères "negatif" devant le résultat (cela revient à factoriser -1 durant notre calcul).
    Cette fonction sera utile lorsque nous voudrons faire l'algorithme d'Euclide étendue qui nous demande de traiter des nombres négatifs.
    Le fait d'utiliser la fonction 'supprime_zéros' est essentielle pour l'utilisation de notre fonction en base 2.

    Args:
        l1, l2 (list): seront nos deux listes à multiplier (potentiellement négatives)
        base (int): par défaut 10, sera la base dans laquelle sera faite l'opération

    Return:
        list: une liste représentant le résultat obtenue par la multiplication (qui pourra être négatif, représenté avec un "négatif" en début de liste)
    """
    L1 = deepcopy(l1)
    L2 = deepcopy(l2)
    negatif = False
    if L1[0] == L2[0] == "negatif":
        L1.remove("negatif")
        L2.remove("negatif")
        return soustraction_negative(L2, L1)
    elif L2[0] == "negatif":
        L2.remove("negatif")
        return addition(L1, L2)
    elif L1[0] == "negatif":
        L1.remove("negatif")
        c = addition(L2, L1)
        c.insert(0, "negatif")
        return c
    elif est_plus_grand(L2, L1):
        negatif = True
        L1, L2 = L2, L1
    taille1 = len(L1)
    taille2 = len(L2)
    new = []
    compteur = 0
    for i in range(taille2):
        L2[taille2 - 1 - i] += compteur
        if L1[taille1 - 1 - i] - L2[taille2 - 1 - i] < 0:
            compteur = 1
            new = [base + L1[taille1 - 1 - i] - L2[taille2 - 1 - i]] + new
        else:
            new = [L1[taille1 - 1 - i] - L2[taille2 - 1 - i]] + new
            compteur = 0
    if compteur == 1:
        L1[taille1 - taille2 - 1] -= 1
    new = L1[: (taille1 - taille2)] + new
    supprime_zéros(new)

    if negatif:
        new.insert(0, "negatif")

    return new


def multiplication(L1, L2, base=10):
    """
    Multiplication de deux listes

    Notre fonction multiplication est plutôt simple dans sa conception (ce qui implique malheureusement dans notre cas une compléxité très élevée, comme développé dans le rapport de projet).
    Nous l'avons faite par intuition et nous n'avons pas cherché à refaire d'algorithme plus rapide (même si nous nous sommes finalement renseignés sur le sujet).
    Au départ, cela ne nous a pas posé de problèmes mais lorsque nous avons commencé à travailler sur des listes très grandes, cela a rapidement ralenti nos calculs.
    Nous faisons simplement des additions en boucle, de la même manière qu'en primaire lorsqu'on apprenait à poser des multiplications. Pour chaque élément de la seconde liste on additionne la première avec elle même autant de fois que la valeur de l'élément (en faisant attention aux puissances de 10 selon la position de l'élément de L2 dans sa liste).
    Cette fonction ne peut traiter que la multiplication d'entiers naturels.

    Args:
        L1, L2 (list): nos deux listes à multiplier
        base (int): par défaut 10, sera la base dans laquelle sera faite l'opération

    Return:
        list: le résultat de notre multiplication
    """
    resultat = [0]
    if len(L1) == len(L2):
        L1 = [0] + L1
    L1, L2 = max(L1, L2, key=len), min(L1, L2, key=len)
    for i in range(len(L2)):
        for j in range(len(L1)):
            resultat = addition(
                resultat,
                (
                    nombre_vers_liste(L1[len(L1) - j - 1] * L2[len(L2) - i - 1])
                    + [0 for i in range(i + j)]
                ),
            )
    return resultat


"""
def division(l1, l2):
    L1 = deepcopy(l1)
    L2 = deepcopy(l2)
    Q = []
    R = []
    while est_plus_grand(L1, L2) or (L1[0] == 0 and len(L1) > 1):

        if L1[0] == [0 for i in range(len(L1))]:
            Q.append(0)
            L1.pop(0)

        decoupage = L1[: ((len(L2) + 1))]  # prog marche pas pour liste de meme taille

        decoupage = supprime_zéros(decoupage)

        i = [1]
        while est_plus_grand(decoupage, multiplication(i, L2)):

            i = addition(i, [1])

        newdecoupage = soustraction(decoupage, multiplication(L2, soustraction(i, [1])))

        for j in range(
            len(L2) + 1
        ):  # voila ou etaos ma faute depuis le debut envie de ma suisider fort putin de +1 pour 2h de taff yes
            if len(L1) != 0:
                L1.pop(0)
        newdecoupage = supprime_zéros(newdecoupage)
        L1 = newdecoupage + L1
        print(L1)

        Q = Q + soustraction(i, [1])

    reste = soustraction(l1, multiplication(Q, l2))
    supprime_zéros(reste)
    if reste == l2:
        Q = addition(Q, [1])
        reste = [0]

    return [Q, reste]
"""


def division(l1, l2):
    """Division de deux listes

    Je tiens tout d'abord à spécifier que c'est un bonheur pour nous de vous présenter cette fonction en vue du temps passé dessus.
    Je tiens également à féliciter notre groupe pour le sang, la sueur et les larmes qu'il a laissé au travers de ces lignes de code et spécifiquement au travers de cette fonction au bout de laquelle nous avons finalement trouvé un résultat plus que satisfaisant.
    La logique de cette fonction est légérement différente que les autres car nous n'allons pas commencer par traiter le début du nombre (la fin de la liste) mais nous allons plutôt partir du début de la première liste.
    Nous allons récupérer le début de la première liste (selon la taille de la seconde liste) et effectuer des soustraction entre la partition de la première liste et la seconde liste. Cela nous permet donc de faire augmenter le quotient.
    Ensuite, si la partition de L1 doit changer, il ne faut pas oublier de modifier le quotient comment nous augmenter le quotient (qui doit gagner des puissances de 10) selon la nouvelle taille de la partition.

    Args:
        l1, l2 (list): nos deux listes à diviser (nous divisons l1 par l2)

    Return:
        list: le résultat de notre division qui est une liste de deux listes, le quotient puis le reste
    """
    L1 = deepcopy(l1)
    L2 = deepcopy(l2)
    L1 = supprime_zéros(L1)
    L2 = supprime_zéros(L2)
    Q = []
    restedecoupage = 0
    decoupage = L1[: (len(L2))]
    while est_plus_grand(L1, L2):
        V = [0]
        while est_plus_grand(decoupage, L2):
            decoupage = soustraction(decoupage, L2)
            V = addition([1], V)

        Q = Q + V
        if len(l1) - restedecoupage == len(L2):
            break
        restedecoupage += 1
        decoupage = decoupage + [l1[len(L2) + restedecoupage - 1]]

        if L1 == [0 for i in range(len(L1))]:
            Q += [0 for j in range(len(L1))]
    Q = supprime_zéros(Q)
    decoupage = supprime_zéros(decoupage)
    if decoupage == []:
        decoupage = [0]

    return [Q, decoupage]


def modulo(L1, modulo):
    """
    Calcul le résultat d'un nombre modulé

    Cette fonction nous renvoie simplement le reste d'une division euclidienne (fonction déjà existante dans nos programmes).

    Args:
        L1 (list): correspond à la liste à moduler
        modulo (list): correspond au modulo à appliquer

    Return:
        list: le reste de la division euclidienne des deux entrées
    """
    x, reste = division(L1, modulo)
    return reste


def expo_modulaire(l1, exposant, module):
    """
    Mettre un nombre à une puissance et le moduler en même temps

    Dans notre programme RSA, nous devrons mettre notre message à une puissance et y appliquer un modulo. Cependant, faire ces deux opérations de façon disjointe est beaucoup trop long car nous devrions traiter des nombres extrèmement grands.
    Nous avons donc trouver un moyen de combiner ces deux opérations.
    Nous passons notre exposant en binaire et nous pouvons donc traiter chaque "bit" de notre exposant indépendamment.
    La méthode de cette fonction est expliquée en détail dans le rapport de projet et est appuyé par la formule correspondante.

    Args:
        l1 (list): la liste que nous passerons à l'exposant et modulerons
        exposant (list): l'exposant que l'on applique à la liste
        module (list) : le module que l'on applique à la liste

    Return:
        list: le résultat de notre liste en entrée mis à la puissance correspondant à l'exposant puis modulée par notre module
    """
    L1 = deepcopy(l1)
    L1 = supprime_zéros(L1)
    res = [1]
    expobinaire = passage_binaire(exposant)

    for i in range(len(expobinaire) - 1, -1, -1):
        if expobinaire[i] == 1:
            res = multiplication(res, L1)
            res = modulo(res, module)

        L1 = multiplication(L1, L1)
        L1 = modulo(L1, module)

    return res


def euclide_etendu(L1, L2):
    """
    Algorithme d'Euclide étendu

    Ce programme est une application directe de l'algorithme d'Euclide étendu, développé dans la partie mathématique du rapport de projet.

    Args:
        L1, L2 (list): Nos deux listes auxquelles on applique l'algorithme

    Return:
        list: 3 éléments sont rendus par l'algorithme, le PGCD et les coefficients de Bezout
    """
    L = deepcopy(L2)
    echange = False
    if est_plus_grand(L2, L1):
        L2, L1 = L1, L2
        echange = True
    x = [1]
    X = [0]
    y = [0]
    Y = [1]
    while L2 != [0]:
        Q = division(L1, L2)[0]
        L1, L2 = L2, division(L1, L2)[1]
        t = soustraction_negative(x, multiplication_negative(Q, X))
        X, x = t, X
        c = soustraction_negative(y, multiplication_negative(Q, Y))
        Y, y = c, Y
    if echange:
        x, y = y, x

    if x[0] == "negatif":
        x.remove("negatif")
        g = soustraction_negative(L, x)
        x = g
    return L1, x, y  # on a l'égalité pgcd= xL1+yL2  ,l'inverse de  L1 modulo L2 est x
