# Création d'un dictionnaire de l'ensemble de nos caractères
dictionnaire = []
# Ponctuation
for code in range(33, 48):
    dictionnaire.append(chr(code))
dictionnaire.append(":")
dictionnaire.append(";")
dictionnaire.append("?")
# Lettres majuscules
for code in range(65, 91):
    dictionnaire.append(chr(code))
# Lettres minuscules
for code in range(97, 123):
    dictionnaire.append(chr(code))
# Le caractère espace
dictionnaire.append(" ")
# Les accents
dictionnaire.append("é")
dictionnaire.append("è")
dictionnaire.append("à")


# Codage chiffrement de César (par décalage)
"""
Cas général:
On cherche l'indice ASCII de chaque caractère de notre message pour le convertir en l'indice de notre dictionnaire.
On va ensuite appliqué un décalage à cet indice (modulo la taille de notre dictionnaire)
indice = ord(char) - (nombre nécessaire à la conversion)
resultat += chr((indice + décalage) % (taille du dictionnaire))
"""


def chiffrement_cesar(texte, décalage):
    """Chiffrement d'un message par la méthode de César

    Nous nous interessons ici à la méthode de chiffrement dites "de César" ou par décalage.
    Le rapport détaille un peu plus son fonctionnement.
    Nous choisissons simplement un texte et un décalage et la fonction va décaler tous les charactères de la valeur du décalage.
    Dans cette fonction, nous utilisons un dictionnaire créé par nous-même et nous n'utilisons ni le code ASCII ni aucun autre protocole pour convertir des charactères car l'interet de ce chiffrement ne réside pas là.
    La fonction va prendre tous les charactères du message à coder, va lui attribuer un nombre (sa place dans le dictionnaire prédéfini) et lui rajouter le décalage souhaité.
    Tous les charactères auront donc le même décalage.

    Args :
        décalage (int): sera le nombre entier qui nous servira de décalage (ex: si égal à 10, la 1ère lettre deviendra la 11ème.)
        texte (str): sera la chaine de charactères que nous voudrons coder

    Returns :
        str : La chaine de charactère décalé (le message codé)
    """
    resultat = ""
    # Parcours les caractères du message
    for char in texte:
        resultat += dictionnaire[
            (dictionnaire.index(char) + décalage) % len(dictionnaire)
        ]
    return resultat


def dechiffrement_cesar(message):
    """Déchiffrement d'un message codé par la méthode de César

    Cette fonction est une fonction "pirate" qui va permettre de déchiffrer un message codé par le chiffrement par décalage même sans connaitre la valeur du décalage en question (qui est une sorte de clé).
    Nous savons que l'alphabet est constitué de 26 lettre. Le décalage ne pourra donc avoir que 25 valeurs (le décalage est forcément modulé par 26, ex: un décalage de 1 est pareil qu'un décalage de 27).
    Dans notre cas, le dictionnaire est modifié et est plus grand que 26 charactères donc nous avonns autant de décalage possible que de charactères dans notre dictionnaire.
    Nous allons donc essayer tous les décalage possible (il n'y en a pas beaucoup et c'est très rapide) et regarder celui qui nous donne un résultat cohérent.
    Avec un message chiffré en entrée, nous avons tous les décalages possibiles qui vons sortir de cette fonction mais un seul correspondra à notre message déchiffré.

    Args :
        message (str): sera le message chiffré que le pirate aura récéptionné et tentera de dechiffrer

    Returns :
        La fonction ne retourne rien. C'est un choix que nous avons fait pour que le programme principal soit plus interactif, il affiche simplement tous les résultats qu'il a obtenu en testant tous les décalages. Nous aurions très bien pu renvoyer une liste contenant ces possibilités.
    """
    # On va tester toutes les valeurs de décalage
    for decalage in range(len(dictionnaire)):
        resultat = ""
        for lettre in message:
            resultat += dictionnaire[
                (dictionnaire.index(lettre) + decalage) % len(dictionnaire)
            ]
        print(decalage, "-", resultat)
